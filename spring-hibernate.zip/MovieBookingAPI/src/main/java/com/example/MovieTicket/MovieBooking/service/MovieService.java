package com.example.MovieTicket.MovieBooking.service;

import org.springframework.stereotype.Service;

import com.example.MovieTicket.MovieBooking.Exceptions.IdAlreadyExist;
import com.example.MovieTicket.MovieBooking.Exceptions.IdNotFound;
import com.example.MovieTicket.MovieBooking.Model.Movie;

import java.util.ArrayList;
import java.util.List;

@Service
public class MovieService implements MovieServiceInterface {
    private List<Movie> movies = new ArrayList<>();

    @Override
    public List<Movie> getAllMovies() {
        return movies;
    }

    @Override
    public void addMovie(Movie movie) {
        for (Movie m : movies) {
            if (m.getId().equals(movie.getId())) {
                throw new IdAlreadyExist("Movie ID already exists");
            }
        }
        movies.add(movie);
    }

    @Override
    public Movie getMovieById(String id) {
        for (Movie m : movies) {
            if (m.getId().equals(id)) {
                return m;
            }
        }
        throw new IdNotFound("Movie ID not found");
    }

    @Override
    public void deleteMovieById(String id) {
        movies.removeIf(m -> m.getId().equals(id));
    }

    @Override
    public void updateMovieById(String id, Movie updatedMovie) {
        for (int i = 0; i < movies.size(); i++) {
            Movie m = movies.get(i);
            if (m.getId().equals(id)) {
                movies.set(i, updatedMovie);
                return;
            }
        }
        throw new IdNotFound("Movie ID not found");
    }
}
